# Hasti Jewel Art — future content structure

This folder documents the content model for the next iteration. It does not change the current visual pages or images.

## Project fields
- `slug`: stable URL-safe identifier
- `title`: project title
- `category`: Jewelry / Bags & Accessories / Objects / Collaborations
- `year`: year of project
- `cover_image`: path to an original image in `assets/`
- `gallery`: ordered list of original image paths
- `summary_en`, `summary_tr`, `summary_fa`: language-specific short descriptions
- `body_en`, `body_tr`, `body_fa`: language-specific project descriptions
- `alt_en`, `alt_tr`, `alt_fa`: image alternative text
- `featured`: whether to show on the homepage
- `status`: draft / published

## Proposed future structure
New projects should be added as content records rather than hand-built page layouts. The existing HTML pages and assets remain the source of truth until the migration is tested.

## Important
- Keep original image files unchanged.
- Do not publish empty or machine-generated translations.
- Add canonical URLs, `hreflang`, and `sitemap.xml` only after the final domain and separate language URLs are configured.
- A visual CMS/admin panel is a later step; this folder alone is not an admin panel.
